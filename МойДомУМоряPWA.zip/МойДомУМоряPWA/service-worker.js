const CACHE_NAME = 'dom-u-morya-cache-v1';
const urlsToCache = [
  '/', // Кешируем корневой URL
  '/index.html', // Кешируем основной HTML файл
  // URL фонового изображения из вашего worker.js
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=80',
  '/manifest.json' // Кешируем манифест
];

// Событие 'install' срабатывает, когда Service Worker устанавливается
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Открыт кеш');
        return cache.addAll(urlsToCache); // Добавляем все необходимые ресурсы в кеш
      })
  );
});

// Событие 'fetch' перехватывает сетевые запросы
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Если ресурс найден в кеше, возвращаем его
        if (response) {
          return response;
        }
        // Иначе, делаем сетевой запрос
        return fetch(event.request);
      })
  );
});

// Событие 'activate' срабатывает, когда Service Worker активируется
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME]; // Список текущих кешей, которые должны остаться
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // Удаляем старые кеши, которые не входят в белый список
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Service Worker: Удаление старого кеша:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
